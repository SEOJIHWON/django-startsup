
from time import time
from django.db import models

# Create your models here.


class Post(models.Model) :  # ORM 정의 하나의 게시글을 위한 클래스. model을 상속받아서 클래스를 적용할 준비가된 클래스가 된다.
        title = models.CharField(max_length=32) #2의 거듭제곱 꼴로 선언하는것이 좋다.
        content = models.TextField (default=0, max_length=2048, blank= True, null=True) 
        created_at =models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        
        #likes = models.IntegerField(default=0)

        

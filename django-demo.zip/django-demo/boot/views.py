from django.shortcuts import render

# Create your views here.


def test(request) :
    return render (request , "base.html")


def blog(request) :
    return render (request, "boot/blog.html")

from django.urls import URLPattern, path

from boot import views


urlpatterns = [

    path("base/", views.test),
    path("blog", views.blog)

]